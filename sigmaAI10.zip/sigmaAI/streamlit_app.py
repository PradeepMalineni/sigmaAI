import torch
import types
import streamlit as st
import pandas as pd
from app.data_loader import load_incident_data
from app.vector_search import build_vector_index, retrieve_similar_incidents
from app.model_runner import generate_root_cause_analysis
from app.change_checker import get_related_changes, load_changes, load_cmdb
from app.log_checker import get_logs_for_trace_id, load_logs, summarize_logs

# Patch torch error
torch.classes.__path__ = types.SimpleNamespace(_path=[])

st.set_page_config(page_title="Integrated Platform Environment (IPE) Analyzer", layout="wide")
st.title("🔎 IPE - Integrated Platform Environment")
# def reset_card_state():
#     keys_to_clear = ["incident_selected", "logs_data"]
#     for key in keys_to_clear:
#         if key in st.session_state:
#             del st.session_state[key]
# --- Load Data ---
data_path = "data/incident_data.csv"
df = load_incident_data(data_path)
index, embeddings, model = build_vector_index(df)
cmdb_df = load_cmdb("data/CMDB_Mapping.csv")
change_df = load_changes("data/change.csv")
logs_df = load_logs("data/Logs_Lookup.csv")

# --- Card Selection ---
st.markdown("##")
# st.markdown("### Select a Mode of Analysis")

# Session state keys to isolate selections
if "active_card" not in st.session_state:
    st.session_state.active_card = None
# st.markdown("""
# <style>
# button[kind="primary"] {
#     background-color: #1f1f1f !important;
#     color: white !important;
#     border: 1px solid #444 !important;
#     border-radius: 16px !important;
#     padding: 30px 20px !important;
#     font-size: 20px !important;
#     box-shadow: 0 4px 12px rgba(0,0,0,0.3);
#     margin-bottom: 20px;
#     height: 150px;
#     text-align: left;
# }
# button[kind="primary"]:hover {
#     background-color: #2e2e2e !important;
#     border-color: #888 !important;
# }
# </style>
# """, unsafe_allow_html=True)
# Custom CSS for cards and buttons
# Inject the HTML/CSS

# Custom CSS styling


import streamlit as st

# Custom CSS for cards and buttons
st.markdown("""
<style>
.card-wrapper {
    display: flex;
    justify-content: space-evenly;
    margin-top: 30px;
    gap: 20px;
    padding-bottom: 60px;
}

.card {
    background: #f2f2f2;
    border-radius: 18px;
    padding: 20px 20px 40px;
    width: 90%;
    max-width: 380px;
    min-height: 150px;
    border: 1px solid #333;
    box-shadow: inset 0 0 0.5px rgba(255, 255, 255, 0.1);
    text-align: center;
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    overflow: visible;
}
.card::after {
    content: "";
    position: absolute;
    bottom: 0;
    width: 60%;
    height: 1px;
    background: rgba(255,255,255,0.05);
}
.stButton > button {
    position: absolute;
    bottom: -25px;
    left: 45%;
    transform: translateX(-50%);
    width: 70%;
    padding: 0.65rem 1.1rem;
    font-size: 1.1rem;
    border-radius: 12px;
    border: 1px solid #555;
    background: linear-gradient(135deg, #3a3a3a, #1f1f1f);
    color: #f5f5f5;      
    font-weight: 500;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.4);
    z-index: 2;
    transition: all 0.25s ease;
}

.stButton > button:hover {
    background: linear-gradient(135deg, #4a4a4a, #2a2a2a);
    border-color: #888;
    box-shadow: 0 6px 14px rgba(0, 0, 0, 0.5);
}

.card-desc {
    font-size: 15px;
    color: #333;
    font-style: italic;
    flex-grow: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
}
.small-button .stButton > button {
    padding: 0.25rem 0.6rem;
    font-size: 0.8rem;
    width: auto;
    border-radius: 6px;
    line-height: 1.2;
    min-height: 20px;
    margin-bottom: 2rem; /* 🔥 This adds vertical spacing */
}

</style>
""", unsafe_allow_html=True)


# Function to reset card state
def reset_card_state():
    st.session_state.active_card = None
    for key in ["rca_result", "rca_text_source", "rca_similar_data", "incident_selected", "logs_data"]:
        if key in st.session_state:
            del st.session_state[key]

# Initialize session state if not already set
if "active_card" not in st.session_state:
    st.session_state.active_card = None

# Card and button layout
col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("""
    <div class="card">
        <div class="card-desc">Delve into issues with deeper insights using past incidents, enhanced by GenAI-powered RCA.</div>
        <div class="stButtonContainer" id="smart-button"></div>
    </div>
    """, unsafe_allow_html=True)
    btn = st.button("🧠 Smart Issue Explorer", key="smart")
    if btn:
        reset_card_state()
        st.session_state.active_card = "smart"

with col2:
    st.markdown("""
    <div class="card">
        <div class="card-desc">Get detailed visibility into an ongoing incident and discover related change requests ranked by correlation.</div>
        <div class="stButtonContainer" id="smart-button"></div>
    </div>
    """, unsafe_allow_html=True)
    if st.button("🧾 Incident Investigator", key="incident"):
        reset_card_state()
        st.session_state.active_card = "incident"

with col3:
    st.markdown("""
    <div class="card">
        <div class="card-desc">Gain deeper understanding of system behavior through GenAI-driven log summarization.</div>
        <div class="stButtonContainer" id="smart-button"></div>
    </div>
    """, unsafe_allow_html=True)
    if st.button("🧬 TraceIQ", key="tracer"):
        reset_card_state()
        st.session_state.active_card = "tracer"





# Display active card state (for debugging or functionality)
# col1, col2, col3 = st.columns(3)

# with col1:
#     if st.button("🧠 Smart Issue Explorer", use_container_width=True):
#         reset_card_state()
#         st.session_state.active_card = "smart"

# with col2:
#     if st.button("🧾 Incident Investigator", use_container_width=True):
#         reset_card_state()
#         st.session_state.active_card = "incident"

# with col3:
#     if st.button("🧬 TraceIQ", use_container_width=True):
#         reset_card_state()
#         st.session_state.active_card = "tracer"

st.divider()

# --- Smart Issue Explorer ---
if st.session_state.active_card == "smart":
    st.subheader("🧠 Smart Issue Explorer")
    query = st.text_input("Enter issue or symptom description:")

    if query:
        incident_row = df[df["incident_id"] == query]
        query_text = (
            incident_row.iloc[0]["combined_text"] if not incident_row.empty else query
        )

        with st.spinner("Retrieving similar incidents..."):
            similar = retrieve_similar_incidents(query_text, model, index, df)
            st.dataframe(similar[["incident_id", "description", "resolution", "cause"]])
        
        st.markdown('<div class="small-button">', unsafe_allow_html=True)
        if st.button("Analyze"):
            st.session_state.rca_text_source = query_text
            st.session_state.rca_similar_data = similar
            with st.spinner("Generating Root Cause Analysis..."):
                st.session_state.rca_result = generate_root_cause_analysis(
                    st.session_state.rca_text_source,
                    st.session_state.rca_similar_data
                )
        st.markdown('</div>', unsafe_allow_html=True)

        # Show RCA if previously generated
        if "rca_result" in st.session_state and st.session_state.active_card == "smart":
            st.markdown("### 🧠 Probable Root Cause and Resolution")
            st.markdown(st.session_state.rca_result)
        st.markdown("---")  # adds a horizontal line
        st.markdown("### 🔍 Explore Further")

        if st.checkbox("🔍 Do you want to dig deeper into either of these incidents?", value=False):
            for i, row in similar.iterrows():
                col1, col2 = st.columns([6, 1])
                with col1:
                    st.write(f"**{row['incident_id']}** | {row['description']} | {row['cause']}")
                with col2:
                    st.markdown('<div class="small-button">', unsafe_allow_html=True)
                    if st.button("Review", key=f"review_issue_{i}"):
                        st.session_state["incident_selected"] = row.to_dict()
                    st.markdown("</div>", unsafe_allow_html=True)
                    st.markdown("<div style='margin-bottom: 1rem;'></div>", unsafe_allow_html=True)

# --- Incident Investigator ---
elif st.session_state.active_card == "incident":
    st.subheader("🧾 Incident Investigator")
    inc_id = st.text_input("Enter Incident ID:")

    if inc_id and inc_id in df["incident_id"].values:
        selected = df[df["incident_id"] == inc_id].iloc[0].to_dict()
        st.session_state["incident_selected"] = selected
    else:
        if inc_id:
            st.warning("Incident ID not found.")

# --- TraceIQ ---
elif st.session_state.active_card == "tracer":
    st.subheader("🧬 TraceIQ")
    trace_input = st.text_input("Enter Trace ID to investigate:")
    if trace_input:
        logs = get_logs_for_trace_id(trace_input, logs_df)
        if logs:
            st.markdown(f"**🧠 Log Summary for Trace ID: `{trace_input}`**")
            summary = summarize_logs(logs)
            for line in summary:
                clean_line = line.strip("•○–- ").strip()
                st.markdown(f"- {clean_line}")
        else:
            st.info("No logs found for this trace ID.")

# --- Shared RCA Panels ---
if "incident_selected" in st.session_state:
    incident = st.session_state["incident_selected"]

    with st.expander("📋 Incident Review (IR)", expanded=True):
        st.write(f"**Incident ID:** {incident['incident_id']}")
        st.write(f"**Description:** {incident['description']}")
        st.write(f"**App:** {incident['app']} ({incident['app_name']})")
        st.write(f"**Date:** {incident['incident_date']}")
        st.write(f"**Cause:** {incident['cause']}")
        st.write(f"**Resolution:** {incident['resolution']}")

    with st.expander("🔁 Change Review (CR)", expanded=False):
        st.write("Looking for related Change Requests...")
        app = incident['app']
        incident_date = incident['incident_date']
        related_crs = get_related_changes(app, incident_date, change_df)

        def correlation_weight(cr_date):
            try:
                return abs((pd.to_datetime(incident_date) - pd.to_datetime(cr_date)).days)
            except:
                return 999

        if related_crs:
            related_crs = sorted(related_crs, key=lambda x: correlation_weight(x["date"]))
            top_related = related_crs[:5]
            selected_cr = incident.get('cr_number', '')

            for cr in top_related:
                cr_date = pd.to_datetime(cr["date"])
                inc_date = pd.to_datetime(incident_date)
                days_diff = abs((inc_date - cr_date).days)

                if selected_cr:
                    status = '🔴 Strong correlation' if cr['cr_number'] == selected_cr else '🟠 Partial correlation'
                else:
                    status = '🟢 All clear' if days_diff > 3 else ('🟠 Partial correlation' if days_diff > 1 else '🔴 Strong correlation')

                ci_list = cmdb_df[cmdb_df["app"] == cr["app"]]["ci_id"].tolist()
                ci_text = ", ".join(ci_list)
                app_name = cr["app"]

                st.markdown(
                    f"""🔹 **CR:** `{cr['cr_number']}`  
📅 **Date:** `{cr['date']}`  
🧩 **App:** `{app_name}`  
🧮 **CI(s):** `{ci_text}`  
📊 **Correlation:** {status}"""
                )
                st.markdown("---")
        else:
            st.info("No related Change Requests found.")

    with st.expander("📄 Logs Check (LC)", expanded=False):
        trace_id = incident.get("trace_id", "")
        if trace_id:
            logs = get_logs_for_trace_id(trace_id, logs_df)
            if logs:
                st.markdown(f"**🧠 Log Summary for Trace ID: `{trace_id}`**")
                summary = summarize_logs(logs)
                for line in summary:
                    clean_line = line.strip("•○–- ").strip()
                    st.markdown(f"- {clean_line}")
            else:
                st.info("No logs found for this trace ID.")
        else:
            st.info("No trace ID associated with this incident.")
